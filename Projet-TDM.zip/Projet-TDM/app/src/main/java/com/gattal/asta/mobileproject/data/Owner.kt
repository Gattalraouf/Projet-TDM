package com.gattal.asta.mobileproject.data

import java.io.Serializable

class Owner(var name: String, var pic: String, var email: String, var phone: String) : Serializable