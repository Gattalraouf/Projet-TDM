package com.gattal.asta.mobileproject.data

import java.io.Serializable

class Product(
    var owner: Owner,
    var imgs: List<String>,
    var name: String,
    var descr: String,
    var Wilaya: String,
    var Datedep: String
) : Serializable